Thanks for checking out my code! Please be aware that this project is not fully complete, as it was a 24 hour hackathon. 

The temporary API database from which employees were pulled has been disabled, so it no longer runs. With that in mind, enjoy!