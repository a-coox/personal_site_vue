// client-side js
// run by the browser each time your view template is loaded

// by default, you've got jQuery,
// add other scripts at the bottom of index.html

var me;

$(function() {
  console.log('hello world :o');
  
  /*$.get('/dreams', function(dreams) {
    dreams.forEach(function(dream) {
      $('<li></li>').text(dream).appendTo('ul#dreams');
    });
  });*/
  var angular = require('angular');
  
  //TODO: get real tanda_id from login
  var app=angular.module('refresh', []).controller('refresh_control', function($scope,$interval) {
    var time = $interval(function() {
      $.get('/currentUser', (user) => {
        if (user.name != undefined) {
          console.log("got a user!");
          me = user;
          $('#welcome').text(`Welcome, ${user.name}!`);
        } else {
          $('#welcome').text("Welcome!");
        }
      });
    }, 100);
  });
  
  $.get('/employees', (employees) => {
        console.log(employees);
        employees.forEach( (employee) => {
          $('<li></li>').text(employee.name).appendTo('ul#dreams');
        });
      });
  
  
  
  $('#submitBtn').click( () => {
    //FOR EACH ENTRY
    if (me == undefined) {
      return;
    }
    var bets = [];
    $.post('/bet', {creator: me.id, bet_on: bets});
  });
});
