var topWinners;    //IDs for users
var people_data;          //All user details
var me = {
	id: 450399,
	photo: "https://s3.amazonaws.com/PayAus/logins/photos/050/330/358/icon/login_0009_636447953480000000.png",
	name: "Maurice Gross"
};

$(document).ready(function(){
  topWinners = [0,0,0,0,0];
  update_people_data();
  init_btn();
  init_me();
})

function init_me() {
  $.get('/currentUser', (user) => {
    if (user.name != undefined) {
      me = user;
      $('#name').text(user.name);
    } else {
      $('#name').text(me.name);
    }
  });
}


function init_btn() {
    $("#submitbtn").click(function() {
      if (me == undefined) {
        console.log("here2");
        return;
      }
      console.log("betting someone");
      for (var i = 0; i < topWinners.length; i++) {
        console.log("HERE");
        //console.log({creator: me.id, bet_on: topWinners[i]});
        //$.post('/bet', JSON.stringify({"creator":me.id,"bet_on":topWinners[i]}));
        $.ajax({
          type: 'POST',
          data: JSON.stringify({"creator":me.id,"bet_on":topWinners[i]}),
          contentType: 'application/json',
          url: '/bet'
        });
      }      
      location.href = "/check.html";
    });
}

function init_hover_info() {
  //   $( ".person" ).hover(
  //   function() {
  //     person = find_person_from_id(this.id);
  //     $("#focusPerson").css("background-image",'url("'+person.photo+'")');
  //     $("#focusName").text(person.name);
  //   }, function() {
  //     console.log("out");
  //   }
  // );
  $(".person").click(function() {
    var person = find_person_from_id(this.id);
    $("#focusPerson").css("background-image",'url("'+person.photo+'")');
    $("#focusName").text(person.name);
  })
  $(".person").hover(function() {
    var person = find_person_from_id(this.id);
    $("#focusPerson").css("background-image",'url("'+person.photo+'")');
    $("#focusName").text(person.name);
  })
}


function init_people() {
  var html_string = "";
  console.log(people_data);
  for (var i=0; i<people_data.length; i++) {
    var person = people_data[i];
    if (i==4) {
        html_string += '<img id="'+person.id+'" src="'+person.photo+'" class="person"/><img src="https://cdn.glitch.com/e20d3b7f-db76-49c3-9e65-85b09ade89a9%2Fstar.png?1509169869285" class="icon"/>';
    } else if (i==2) {
         html_string += '<img id="'+person.id+'" src="'+person.photo+'" class="person"/><img src="https://cdn.glitch.com/e20d3b7f-db76-49c3-9e65-85b09ade89a9%2Fflame.png?1509169870424" class="icon"/>';           
    } else if (i==6) {
         html_string += '<img id="'+person.id+'" src="'+person.photo+'" class="person"/><img src="https://cdn.glitch.com/e20d3b7f-db76-49c3-9e65-85b09ade89a9%2FCROWN.png?1509169939562" class="icon"/>';           
    } else if (i==7) {
         html_string += '<img id="'+person.id+'" src="'+person.photo+'" class="person"/><img src="https://cdn.glitch.com/e20d3b7f-db76-49c3-9e65-85b09ade89a9%2Fstar.png?1509169869285" class="icon"/>';           
    } else {
      html_string += '<img id="'+person.id+'" src="'+person.photo+'" class="person"/>';
    }
    
  }
  $("#people-container").html(html_string);
}

function init_drag_drop() {
  $(".person").draggable({
    revert:"invalid",
    snap:"winner",
    helper:"clone"
  });

  $(".winner").droppable({
    classes: {
      "ui-droppable-active": "droppable",
      "ui-droppable-hover": "dropping"
    },
    drop: function( event, ui ) {
      $( this ).addClass( "droppable" );
      var peopleID = event.target.id;
      var winnerID = ui.draggable[0].id;
      add_winner(peopleID, winnerID);
      update_winner_photos();
    }
  });
}


function add_winner(winnerID, peopleID) {
  for (var i=0; i<topWinners.length; i++) {
    console.log(typeof peopleID, typeof topWinners[i]);
    if (peopleID == topWinners[i]) {
      console.log("found one",topWinners[i]);
      topWinners[i] = 0;
    }
  }
  topWinners[winnerID] = peopleID;
  console.log(topWinners);
}

function update_winner_photos() {
  for (var i=0; i<5; i++) {
    update_winner_photo(i);
  }
}

function update_winner_photo(winnerID) {
  var winner = $("#"+winnerID);
  var person = $("#"+topWinners[winnerID]);
  if (topWinners[winnerID]==0) {
    $(winner).css("background-image",'url("https://cdn.glitch.com/e20d3b7f-db76-49c3-9e65-85b09ade89a9%2Fdefault.png?1509169869789")');
  } else {
    $(winner).css("background-image",'url("'+person.attr("src")+'")');
  }

}

function update_people_data() {
  $.get('/employees', (employees) => {
    console.log(employees);
    people_data = employees;
    init_people();
    init_drag_drop();
    init_hover_info();
  });
}
