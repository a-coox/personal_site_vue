
function find_person_from_id(id) {
  for (var i=0; i<people_data.length; i++) {
    if (people_data[i].id==id) {
      console.log("out");
      return people_data[i];
    }
  }
  return null;
}
