
var betting_data = [
  	{
  		creator: {
  			id: 45007,
  			name: "Paul Haley",
  			photo: "https://s3.amazonaws.com/PayAus/logins/photos/050/318/480/icon/login_0005_636447888080000000.png"
  		},
  		bet_on: [
  			{
  			id: 45007,
  			name: "Paul Haley",
  			photo: "https://s3.amazonaws.com/PayAus/logins/photos/050/318/480/icon/login_0005_636447888080000000.png"
  			},
  			{
  			id: 45007,
  			name: "Paul Haley",
  			photo: "https://s3.amazonaws.com/PayAus/logins/photos/050/318/480/icon/login_0005_636447888080000000.png"
  			},
        {
  			id: 448749,
  			name: "Hayley Faulkner",
  			photo: "https://s3.amazonaws.com/PayAus/logins/photos/050/318/480/icon/login_0005_636447888080000000.png"
  			},
        {
  			id: 450052,
  			name: "Hayley Faulkner",
  			photo: "https://s3.amazonaws.com/PayAus/logins/photos/050/351/272/icon/logout_0000_636448080620000000.png"
  			},
  			{
  			id: 450054,
  			name: "Aaron Coox",
  			photo: "https://s3.amazonaws.com/PayAus/logins/photos/050/332/328/icon/login_1337_636447976680000000.png"
  			}
  		]
  	},
  	{
  		creator: {
  			id: 45007,
  			name: "bbbbbb",
  			photo: "https://s3.amazonaws.com/PayAus/logins/photos/050/318/480/icon/login_0005_636447888080000000.png"
  		},
  		bet_on: [
  			{
  			id: 45007,
  			name: "Paul Haley",
  			photo: "https://s3.amazonaws.com/PayAus/logins/photos/050/318/480/icon/login_0005_636447888080000000.png"
  			},
  			{
  			id: 448749,
  			name: "Hayley Faulkner",
  			photo: "https://s3.amazonaws.com/PayAus/logins/photos/050/318/480/icon/login_0005_636447888080000000.png"
  			},
  			{
  			id: 450052,
  			name: "Hayley Faulkner",
  			photo: "https://s3.amazonaws.com/PayAus/logins/photos/050/351/272/icon/logout_0000_636448080620000000.png"
  			},
  			{
  			id: 450054,
  			name: "Aaron Coox",
  			photo: "https://s3.amazonaws.com/PayAus/logins/photos/050/332/328/icon/login_1337_636447976680000000.png"
  			}
  		]
  	}
  ];

$(document).ready(function(){
  update_betting_data();
  //update_results();
  //test_update();
  $("#submitbtn").click(function() {
        location.href = "authed_index.html";
    });
})

function test_update() {
  
}

function update_results() {
  var wrapper = "";
  for (var i=0; i<betting_data.length; i++) {
    console.log(betting_data[i].creator);
    console.log(betting_data[i].bet_on);
    if(betting_data[i].bet_on.length < 5) {
      continue;
    }
    wrapper += `<div class = "winner-wrapper">
      <p>${betting_data[i].creator.name} guessed <span>X</span> correct!</p>
      <div class = "flex">
          <div class = "winnerContainer">
              <div id=0 class="winner correct">
              </div>
              <p>${betting_data[i].bet_on[0].name}</p>
          </div>
          <div class = "winnerContainer">
              <div id=1 class="winner correct">
              </div>
              <p>${betting_data[i].bet_on[1].name}</p>
          </div>
          <div class = "winnerContainer">
              <div id=2 class="winner incorrect">
              </div>
              <p>${betting_data[i].bet_on[2].name}</p>
          </div>
          <div class = "winnerContainer">
              <div id=3 class="winner correct">
              </div>
              <p>${betting_data[i].bet_on[3].name}</p>
          </div>
          <div class = "winnerContainer">
              <div id=4 class="winner incorrect">
              </div>
              <p>${betting_data[i].bet_on[4].name}</p>
          </div>
      </div>
    </div>`;
  }
  
  $("#message").append(wrapper);
  
}

function update_betting_data() {
  $.get("/betResults", (results) => {
    betting_data = results;
    update_results();
  });
  /*betting_data = [
  	{
  		creator: {
  			id: 45007,
  			name: "Paul Haley",
  			photo: "https://s3.amazonaws.com/PayAus/logins/photos/050/318/480/icon/login_0005_636447888080000000.png"
  		},
  		bet_on: [
  			{
  			id: 45007,
  			name: "Paul Haley",
  			photo: "https://s3.amazonaws.com/PayAus/logins/photos/050/318/480/icon/login_0005_636447888080000000.png"
  			},
  			{
  			id: 45007,
  			name: "Paul Haley",
  			photo: "https://s3.amazonaws.com/PayAus/logins/photos/050/318/480/icon/login_0005_636447888080000000.png"
  			}
  		]
  	},
  	{
  		creator: {
  			id: 45007,
  			name: "bbbbbb",
  			photo: "https://s3.amazonaws.com/PayAus/logins/photos/050/318/480/icon/login_0005_636447888080000000.png"
  		},
  		bet_on: [
  			{
  			id: 45007,
  			name: "Paul Haley",
  			photo: "https://s3.amazonaws.com/PayAus/logins/photos/050/318/480/icon/login_0005_636447888080000000.png"
  			},
  			{
  			id: 45008,
  			name: "Paul Haley",
  			photo: "https://s3.amazonaws.com/PayAus/logins/photos/050/318/480/icon/login_0005_636447888080000000.png"
  			}
  		]
  	}
  ];*/
}
