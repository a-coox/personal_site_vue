// server.js
// where your node app starts

var clientId     = "ecba15a7ca21045e381f4fc9f2379a652fb8cf5aae5ee4b4d9f12f69fe25be5e"
  , clientSecret = "39bc106759f4c9983b51baf47f00d15c0ef2aafe8fdad51e8e8af47ba9a5ab6c";

var homePage = "https://l8m8.glitch.me";
var redirectUri = homePage + "/callback";
var site = "https://my.tanda.co/api";
var scopes = [
  "me"
];
var token;
var userInfo;

var express = require('express');
var bodyParser = require('body-parser');
var app = express();
var request = require("request");
var open = require("open");
var morgan = require("morgan");
app.set("views", __dirname + "/views");
app.engine("html", require("ejs").renderFile);
app.use(morgan("dev"));
app.use(bodyParser.json());

var employees = []; //Array of employees for choosing
var late = []; //To store the 5 actually late people
var currentUser; //This employee
const APITOKEN = 'Bearer 8076c2622e8e499bfc47d71de2a7b89714fac6506df490ebadc6ca5fdff7e0f5';
const POSTTOKEN = '09685ff7-9e0c-c58b-0586-b2a8a29cc83e';

// http://expressjs.com/en/starter/static-files.html
app.use(express.static('public'));

app.get("/check.html", function (request, response) { 
  response.sendFile(__dirname + '/views/check.html');
});

var oauth2 = require("simple-oauth2")({
  clientID: clientId,
  clientSecret: clientSecret,
  site: site,
  tokenPath: "/oauth/token",
  authorizationPath: "/oauth/authorize"
})

var makeGetRequestToTanda = function(url, callback) {
  refreshTokenIfNeeded(function() {
    oauth2.api("GET", url, {
      access_token: token.token.access_token
    }, callback)
  })
}

var getUserInfo = function(callback) {
  if (userInfo || !token) {
    callback(userInfo || {})
  } else {
    makeGetRequestToTanda("/v2/users/me", function(err, body) {
      userInfo = body
      callback(userInfo)
    })
  }
}

var refreshTokenIfNeeded = function(callback) {
  if (token.expired()) {
    token.refresh(function(err, result) {
      if (err) {
        console.log("Access Token Error")
      } else {
        token = result
        callback()
      }
    })
  } else {
    callback()
  }
}

var toState = function(obj) {
  if (!obj) {
    return ""
  }
  return new Buffer(JSON.stringify(obj)).toString("base64") || ""
}

var fromState = function(string) {
  if (!string) {
    return {}
  }
  return JSON.parse(new Buffer(string, "base64").toString("ascii")) || {}
}

/*
//Send the main page to user when they connect
app.get("/", function (request, response) {
  response.sendFile(__dirname + '/views/index.html');
});*/

get_employees('2017-10-28');

app.get("/employees", (req, res) => {
  res.send(employees);
});

app.get("/currentUser", (req, res) => {
  res.send(currentUser);
});

app.get("/late", (req, res) => {
  res.send(late);
});

app.get("/betResults", (req, res) => {
  var toSend = [];
  for (var i = 0; i < bets.length; i++) {
    var betEntry = {
      creator: {},
      bet_on: []
    };
    betEntry.creator = bets[i][0];
    betEntry.bet_on = bets[i][1];
    toSend[i] = betEntry;
  }
  res.send(toSend);
});

function get_employees(date) {
  var getRequest = {
    method: 'GET',
    url: `https://my.tanda.co/api/v2/rosters/on/${date}?show_costs=false`,
    headers: 
     { 'postman-token': POSTTOKEN,
       'cache-control': 'no-cache',
       authorization: APITOKEN } 
  };
  request(getRequest, (error, response, body) => {
    if (error) throw new Error(error);
    var parsed = JSON.parse(body);
    //console.log("AAAAAA");
    //console.log(parsed.schedules[0].schedules);
    parsed.schedules[0].schedules.forEach( (user) => {
      get_employee(user.user_id);
    });
  });
}

function get_user(id, callback) {
  var getRequest = {
    method: 'GET',
    url: `https://my.tanda.co/api/v2/users/${id}?show_wages=false`,
    headers: 
     { 'postman-token': POSTTOKEN,
       'cache-control': 'no-cache',
       authorization: APITOKEN } 
  };
  request(getRequest, (error, response, body) => {
    if (error) throw new Error(error);
    callback(JSON.parse(body));
  });
}

//Add employee to employees array
function get_employee(id) {
  //console.log("A");
  get_user(id, (user) => {
    console.log(`Adding employee ${user.id}`);
    employees.push(user);
  });
  //console.log(user)
}

//Add user to the late list
function add_late(id) {
  get_user(id, (user) => {
    late.push(user);
  });
}

/*
// listen for requests :) 
var listener = app.listen(process.env.PORT, function () {
  console.log('Your app is listening on port ' + listener.address().port);
});

*/

/*var options = { method: 'GET',
  url: 'https://my.tanda.co/api/v2/users',
  headers: 
   { 'postman-token': POSTTOKEN,
     'cache-control': 'no-cache',
     authorization: APITOKEN } };

request(options, function (error, response, body) {
  if (error) throw new Error(error);
  employees = JSON.parse(body);
  
  /*for(var i = 0; i < Object.keys(info).length; i++){
    console.log(info[i].name);
    console.log(info[i].id);
  }
});*/

var getRosterOptions = {
  method: 'GET',
  url: 'https://my.tanda.co/api/v2/rosters/on/2017-10-28?show_costs=false', // today's roster
  headers: 
   { 'postman-token': POSTTOKEN,
     'cache-control': 'no-cache',
     authorization: APITOKEN } 
};
var dueIn = new Array();
request(getRosterOptions, function (error, response, body) {
  if (error) throw new Error(error);
  var info = JSON.parse(body);
  var todayS = info.schedules[0].schedules;
  for (var i = 0; i < todayS.length; i++) {
    var sch = todayS[i];
    if (1509112800 <= sch.start && sch.start <= 1509199200) { // todays UNIX times 0000 today to 0000 tomorrow
      dueIn.push([sch.user_id, sch.start, -1]); // -1 is the clock-in time
    }
  }
  console.log(dueIn);
});

// mapping of employees to there bets for the week
// I am only going to assume we are working over a single week.
//var time = 1; // number of days to care about, WE ONLY CARE ABOUT TODAY NOW
var bets = new Array();

app.post("/bet", (req, res) => {
  console.log("BETTING NOW!");
  //console.log(req.body);
  //console.log(req.query);
  // need to check if both employees are in the Tanda employee base
  const betPlacer = parseInt(req.body.creator);
  const betOn = parseInt(req.body.bet_on);
  
  // checking if the betOn person is in the schedule for today
  var coming = false;
  for(var i = 0; i < dueIn.length; i++) {
    if (dueIn[i][0] == betOn) {
      coming = true;
      break;
    }
  }
  if (!coming) {
    res.send('3'); // fail, employee is not working today; SNEEKY CHEATER
    return;
  }
  
  if (betPlacer == betOn) {
    res.send('4'); // fail, ids are the same
    return;
  }
  
  for(var i = 0; i < bets.length; i++) {
    if (parseInt(bets[i][0].id) === betPlacer) {
      get_user(betOn, (target) => {
        bets[i][1].push(target); //append to bet
        console.log(bets);
      });
      res.send('1'); // success, updated entry
      return;
    }
  }
  
  get_user(betPlacer, (placer) => {
    get_user(betOn, (on) => {
      bets.push([placer, [on]]);
      console.log(bets);
    });
  });
  //bets.push([betPlacer, [betOn]]); //creating new a mapping
  res.send('0'); // success, new
});

app.post("/webhook", (req, res) => {
  console.log(req.body.payload); //TODO: actually do something here
  const client = req.body.payload.body;
  if (req.body.payload.topic === "clockin.updated") {
    console.log("client " + client.user_id+ " clocked in at " + client.time);
    get_user(client.user_id, (user) => {
      console.log("clocking a new client");
      currentUser = user;
    });
    
    for (var i = 0; i < dueIn.length; i++) { // this is the code to determine if ppl are l8
      if (dueIn[i][0] == parseInt(client.user_id)) {
        dueIn[i][2] = client.time;
        if (dueIn[i][1] < parseInt(client.time)) { // TODO: figure out their l8ness
          add_late(client.user_id);
        }
      }
    }
  }
  console.log(dueIn); // see changes
});

// ROUTES
app.get("/authenticate", function(req, res) {
  console.log("--- Getting Token ---")
  res.redirect(oauth2.authCode.authorizeURL({
    redirect_uri: redirectUri,
    scope: scopes.join(" "),
    state: toState({redirect: req.query.redirect})
  }))
})

app.get("/callback", function(req, res) {
  oauth2.authCode.getToken({
    code: req.query.code,
    redirect_uri: redirectUri
  }, function(err, result) {
    if (err) {
      console.log("Access Token Error")
    } else {
      token = oauth2.accessToken.create(result)

      var redirect = fromState(req.query.state).redirect || "/"
      res.redirect(redirect)
    }
  })
})

app.get("/", function(req, res) {
  if (!token) {
    res.render(__dirname + '/views/authed_index.html');
  } else {
    refreshTokenIfNeeded(function() {
      getUserInfo(function(userInfo) {
        res.render("authed_index.html", {user_info: userInfo})
      })
    })
  }
})

app.listen(process.env.PORT, function() {
  console.log("make sure that " + redirectUri + " is set as a redirect uri for your app")
})