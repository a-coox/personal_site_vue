Please remember that this app was created in a short time span
by a student team as our first android application. It is not a
finished product, although the underlying path-finding optimisation
& databases do work.